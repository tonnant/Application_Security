<?php /* Smarty version Smarty-3.0.6, created on 2011-03-26 03:54:05
         compiled from "D:\Web\home\gate\www\client/templates\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:239804d8d392d212a69-53406581%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '28338d5cf6ba57f1a246892e4380940e019424ed' => 
    array (
      0 => 'D:\\Web\\home\\gate\\www\\client/templates\\header.tpl',
      1 => 1296429932,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '239804d8d392d212a69-53406581',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<HEAD>
	<title>CN 1</title>
	<LINK href='<?php echo $_smarty_tpl->getVariable('DIR')->value;?>
style.css' rel='stylesheet' type='text/css'>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1251'>
</HEAD>