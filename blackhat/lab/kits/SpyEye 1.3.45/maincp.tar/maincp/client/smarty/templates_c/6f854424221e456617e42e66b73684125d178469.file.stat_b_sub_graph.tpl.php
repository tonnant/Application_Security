<?php /* Smarty version Smarty-3.0.6, created on 2011-02-20 02:59:53
         compiled from "/var/www/maincp/client/templates/stat_b_sub_graph.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6329800204d6083a987f387-03490649%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6f854424221e456617e42e66b73684125d178469' => 
    array (
      0 => '/var/www/maincp/client/templates/stat_b_sub_graph.tpl',
      1 => 1298059128,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6329800204d6083a987f387-03490649',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<br><hr color="#dddddd" size="1"><br>
<h3>Loads for <a href="#" id='gtlink'><b>Global task # <?php echo $_smarty_tpl->getVariable('TID')->value;?>
 </b></a><br>
Create Date: <?php echo $_smarty_tpl->getVariable('CREATE_DATE')->value;?>
</h3>
<table>
<tr><td colspan="2" align='center'><h2><b>Statistic by OS</b></h2></td></tr>
<tr>
	<td align='center' width="50%">
