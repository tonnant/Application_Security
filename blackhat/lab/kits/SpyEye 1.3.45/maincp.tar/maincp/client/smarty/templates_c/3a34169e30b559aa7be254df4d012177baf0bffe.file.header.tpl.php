<?php /* Smarty version Smarty-3.0.6, created on 2011-02-19 20:40:00
         compiled from "/var/www/maincp/client/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5957112824d602aa096b3a0-45039585%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a34169e30b559aa7be254df4d012177baf0bffe' => 
    array (
      0 => '/var/www/maincp/client/templates/header.tpl',
      1 => 1296429932,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5957112824d602aa096b3a0-45039585',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<HEAD>
	<title>CN 1</title>
	<LINK href='<?php echo $_smarty_tpl->getVariable('DIR')->value;?>
style.css' rel='stylesheet' type='text/css'>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1251'>
</HEAD>