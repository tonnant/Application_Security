<?php /* Smarty version Smarty-3.0.6, created on 2011-03-26 03:55:50
         compiled from "Z:/home/gate/www/client/templates\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:324434d8d39968ad4e2-25072365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff920f98024b62c990d555460d064e9a55308f98' => 
    array (
      0 => 'Z:/home/gate/www/client/templates\\header.tpl',
      1 => 1296429932,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '324434d8d39968ad4e2-25072365',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<HEAD>
	<title>CN 1</title>
	<LINK href='<?php echo $_smarty_tpl->getVariable('DIR')->value;?>
style.css' rel='stylesheet' type='text/css'>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1251'>
</HEAD>