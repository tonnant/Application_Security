<?php /* Smarty version Smarty-3.0.6, created on 2011-02-19 18:58:27
         compiled from "/var/www/maincp/client/templates/sett_cat.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13310890214d6012d3cc9c00-51686173%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f4fefc1e39749091a9ece7e39b05fa111632f2e' => 
    array (
      0 => '/var/www/maincp/client/templates/sett_cat.tpl',
      1 => 1295123292,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13310890214d6012d3cc9c00-51686173',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<tr align="left"><td colspan="2"><span id="<?php echo $_smarty_tpl->getVariable('CATEGORY')->value;?>
"><b><?php echo $_smarty_tpl->getVariable('CATEGORY')->value;?>
</b><span></td></tr>