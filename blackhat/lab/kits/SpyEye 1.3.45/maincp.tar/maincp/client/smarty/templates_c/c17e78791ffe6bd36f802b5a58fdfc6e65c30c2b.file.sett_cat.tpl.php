<?php /* Smarty version Smarty-3.0.6, created on 2011-03-26 03:56:48
         compiled from "Z:/home/gate/www/client/templates\sett_cat.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17994d8d39d000c341-40125627%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c17e78791ffe6bd36f802b5a58fdfc6e65c30c2b' => 
    array (
      0 => 'Z:/home/gate/www/client/templates\\sett_cat.tpl',
      1 => 1295123292,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17994d8d39d000c341-40125627',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<tr align="left"><td colspan="2"><span id="<?php echo $_smarty_tpl->getVariable('CATEGORY')->value;?>
"><b><?php echo $_smarty_tpl->getVariable('CATEGORY')->value;?>
</b><span></td></tr>