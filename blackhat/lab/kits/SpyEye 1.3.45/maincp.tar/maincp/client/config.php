<?
	# Server DB configuration
	$db_host = "localhost";
	$db_user = "user";
	$db_pswd = "passw";
	$db_database = "db";
	
	# system
	$root_path = "";
?>